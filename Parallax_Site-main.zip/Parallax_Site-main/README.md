# Parallax_Site
Made a parllax site using HTML and CSS
